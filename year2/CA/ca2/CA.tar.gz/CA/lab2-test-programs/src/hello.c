#include "io.h"

int main(void)
{
  putchar('h');
  putchar('e');
  putchar('l');
  putchar('l');
  putchar('o');
  putchar('\n');
  return 0;
}
